#code written by Joel Hewson for 12SDD AT 3. Date: --/06/2023

import pygame, sys, math, time, random

























#the read and write functions are from an older work of mine


################################################################---Write FUNCTION---################################################################
#use for writing to the program save data file.
def write(SaveVariable, Value):

    
#---------------------------------ASCII Encoding------------------------------
    WriteValue = str(Value)#                                                   
    i = 0#                                                                    
    encodedString = ''#                                                       
    while i<len(WriteValue):#                                                  
        encodedString+= f"{ ord(WriteValue[i]) },"#                            
        i+=1#                                                                  
    WriteValue = encodedString[0:-1]#                                          
#------------------------------------------------------------------------------


#---------------------------------File Writing--------------------------------------------------------------
    with open("Program_Save_Data.data",'r') as Memory:#                                                                       
        txt = Memory.read()#                                                                                                                       
        DataStartLocation = int(txt.find('$S#'+SaveVariable+'$S#')) + (len(SaveVariable)+6)#                    
        DataEndLocation = int(txt.find('#E$'+SaveVariable+'#E$') )#                                                           
        if (DataEndLocation == -1):#                                                                                                             
            with open("Program_Save_Data.data",'w') as Memory:#                                                               
                Memory.write(txt+'$S#'+SaveVariable+'$S#'+str(WriteValue)+'#E$'+SaveVariable+'#E$')#       
        else:#                                                                                      
            newTxt = txt[0:DataStartLocation] + str(WriteValue) + txt[DataEndLocation:len(txt)]#            
            with open("Program_Save_Data.data",'w') as Memory:#                                                               
                Memory.write(newTxt)#                                                                                                            
#------------------------------------------------------------------------------------------------------------
#################################################################################################################################################  








################################################################---READ FUNCTION---################################################################
#use for reading from the program save data file.
def read(SaveVariable):

    #these two lines of code will create a data file if it does not exist
    MakeSureThatDataExists = open('Program_Save_Data.data', 'a')
    MakeSureThatDataExists.close()

    #this code will read the data file and search for key words that declare the start and end of a variable and its contained data.
    #if the variable can not be found then the value returned is 0.
    with open("Program_Save_Data.data",'r') as Memory:
        txt = Memory.read()
        DataStartLocation = int(txt.find('$S#'+SaveVariable+'$S#')) + (len(SaveVariable)+6)
        DataEndLocation = int(txt.find('#E$'+SaveVariable+'#E$') )
        if (DataEndLocation == -1):
            return '0'
        else:

            returnValue = str(txt[DataStartLocation : DataEndLocation])
            i = 0
            decodedList = eval("["+returnValue+"]")
            decodedString = ''
            for item in decodedList:
                decodedString += chr(item)


            returnValue = decodedString
            return returnValue

#################################################################################################################################################

# gets and displays the stored user name
if (read("userName") == "0"):
    userName=input("enter your name here:")
    write("userName", str(userName))
print("\nWelcome "+read("userName"))
time.sleep(1)


import Game_Loop as gameLoopModule
pygame.init()


width = 1200
height = 700
gameClock = pygame.time.Clock();#initialises the game clock

win = pygame.display.set_mode((width,height))
pygame.display.set_caption("game")


playerImage = pygame.image.load("assets/player.png")
pygame.display.set_icon(playerImage)

pygame.mixer.music.load("assets/bits_and_bytes.wav")






###########################################################################################################
def textObjects(text, font, colour = (0,0,0)):
    textObjSurface = font.render(text, True, colour)
    return textObjSurface,textObjSurface.get_rect()

###########################################################################################################
class button:# i made the button into a class instead of what it is in the tutorial. This way the implementation is modular and can scale.
    def __init__(self,x=0,y=0,buttonWidth=200,buttonHeight=65,text="Text",colour=(0,255,0),textSize=30):
        self.x = x
        self.y = y
        self.buttonWidth = buttonWidth
        self.buttonHeight = buttonHeight
        self.textSize = textSize
        self.text = text
        self.colour = colour

    def draw(self, colourHighlight = False):
        if colourHighlight:

            pygame.draw.rect(win, (self.colour[0], self.colour[1], self.colour[2]), (width/2+self.x-self.buttonWidth*0.5, height/2-self.y-self.buttonHeight*0.5, self.buttonWidth, self.buttonHeight))
        else:
            pygame.draw.rect(win, (self.colour[0]*0.5, self.colour[1]*0.5, self.colour[2]*0.5), (width/2+self.x-self.buttonWidth*0.5, height/2-self.y-self.buttonHeight*0.5, self.buttonWidth, self.buttonHeight))
        textSurface, textRect = textObjects(self.text, pygame.font.Font("assets/last-ninja-2-amstrad/last-ninja-2-amstrad.ttf",self.textSize),(255,255,255))
        textRect.center = (width/2+self.x, height/2-self.y)
        win.blit(textSurface, textRect)
    def IsPressed(self):
        isHoveringOver = (pygame.mouse.get_pos()[0] < width/2+self.x+self.buttonWidth*0.5 and\
                pygame.mouse.get_pos()[0] > width/2+self.x-self.buttonWidth*0.5 and\
                pygame.mouse.get_pos()[1] < height/2-self.y+self.buttonHeight*0.5 and\
                pygame.mouse.get_pos()[1] > height/2-self.y-self.buttonHeight*0.5)
        self.draw(isHoveringOver)#this causes the button to 'glow' when the cursor hovers over them
        return isHoveringOver and pygame.mouse.get_pressed()[0]

###########################################################################################################
def helpPageLoop():
    inHelpMenuLoop = True
    while inHelpMenuLoop:
        win.fill((255,255,255))

        titleBG = pygame.image.load("assets/HelpScreen.png")#loads the road image
        titleBG = pygame.transform.scale(titleBG, (width, height) )#sets the scale of the road image
        win.blit(titleBG,(0,0))

        #block 1----------------------------------------------------------------------------
        rectangleXPos, rectangleYPos,rectangleWidth, rectangleHeight = -330,120,500,90
        pygame.draw.rect(win, (0,0,20),\
        ((width/2+rectangleXPos)-rectangleWidth*0.5,(height/2+rectangleYPos)-rectangleHeight*0.5,\
        rectangleWidth,rectangleHeight))

        helpTextSurface, helpTextRect = textObjects("Use A and D to steer the car.",\
        pygame.font.Font("assets/last-ninja-2-amstrad/last-ninja-2-amstrad.ttf",15),(255,255,255))
        helpTextRect.center = (width/2-320, height/2+100)
        win.blit(helpTextSurface, helpTextRect)
        helpTextSurface, helpTextRect = textObjects("Use W to speed up the car.",\
        pygame.font.Font("assets/last-ninja-2-amstrad/last-ninja-2-amstrad.ttf",15),(255,255,255))
        helpTextRect.center = (width/2-320, height/2+130)
        win.blit(helpTextSurface, helpTextRect)
        #block 2-----------------------------------------------------------------------------
        rectangleXPos, rectangleYPos,rectangleWidth, rectangleHeight = 20,0,370,80
        pygame.draw.rect(win, (0,0,20),\
        ((width/2+rectangleXPos)-rectangleWidth*0.5,(height/2+rectangleYPos)-rectangleHeight*0.5,\
        rectangleWidth,rectangleHeight))
        
        helpTextSurface, helpTextRect = textObjects("Collect fuel cans to ",\
        pygame.font.Font("assets/last-ninja-2-amstrad/last-ninja-2-amstrad.ttf",15),(255,255,255))
        helpTextRect.center = (width/2+20, height/2+10)
        win.blit(helpTextSurface, helpTextRect)
        helpTextSurface, helpTextRect = textObjects("refill on fuel.",\
        pygame.font.Font("assets/last-ninja-2-amstrad/last-ninja-2-amstrad.ttf",15),(255,255,255))
        helpTextRect.center = (width/2+20, height/2-20)
        win.blit(helpTextSurface, helpTextRect)
        #block 3-----------------------------------------------------------------------------
        rectangleXPos, rectangleYPos,rectangleWidth, rectangleHeight = 360,120,410,90
        pygame.draw.rect(win, (0,0,20),\
        ((width/2+rectangleXPos)-rectangleWidth*0.5,(height/2+rectangleYPos)-rectangleHeight*0.5,\
        rectangleWidth,rectangleHeight))
        
        helpTextSurface, helpTextRect = textObjects("Avoid the radioactive",\
        pygame.font.Font("assets/last-ninja-2-amstrad/last-ninja-2-amstrad.ttf",15),(255,255,255))
        helpTextRect.center = (width/2+370, height/2+100)
        win.blit(helpTextSurface, helpTextRect)
        helpTextSurface, helpTextRect = textObjects("barrels and stay alive!",\
        pygame.font.Font("assets/last-ninja-2-amstrad/last-ninja-2-amstrad.ttf",15),(255,255,255))
        helpTextRect.center = (width/2+370, height/2+130)
        win.blit(helpTextSurface, helpTextRect)
        #------------------------------------------------------------------------------------


        
        #quit button
        backButton = button(0, -280, 170, 50, "Back", (255,0,0))
        backButton.draw();
        if (backButton.IsPressed()):
            inHelpMenuLoop = False
            
            
        


        pygame.display.update()
        # exit handler
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                inHelpMenuLoop = False
                pygame.quit()
                sys.exit()

###########################################################################################################

def menuLoop():
    inMenuLoop = True
    while inMenuLoop:
        win.fill((255,255,255))

        titleBG = pygame.image.load("assets/TitleScreen.png")#loads the road image
        titleBG = pygame.transform.scale(titleBG, (width, height) )#sets the scale of the road image
        win.blit(titleBG,(0,0))
        
        #menu buttons:

        #play button
        playButton = button(-450, -60, 200, 65, "Play", (0,255,0))
        playButton.draw()
        if (playButton.IsPressed()):
            gameLoopModule.gameLoop()

            #play button
        helpButton = button(-450, -170, 200, 65, "Help", (0,0,255))
        helpButton.draw()
        if (helpButton.IsPressed()):
            helpPageLoop()
            

        #quit button
        quitButton = button(-450, -280, 170, 50, "Quit", (255,0,0))
        quitButton.draw()
        if (quitButton.IsPressed()):
            inMenuLoop = False
            pygame.quit()
            sys.exit()
        


        pygame.display.update()
        # exit handler
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                inMenuLoop = False
                pygame.quit()
                sys.exit()
    
menuLoop()
pygame.quit()
###########################################################################################################
